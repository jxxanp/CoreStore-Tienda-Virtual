package com.corestore;

// ===== IMPORTACIONES =====
import com.corestore.animaciones.CarritoAnimacion;
import com.corestore.animaciones.FavoritoAnimacion;
import com.corestore.ventanas.VentanaOfertas;
import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import java.net.URL;
import javafx.scene.layout.Priority;
public class Catalogo extends Application {

    // ===== VARIABLES =====
    private int carritoCantidad = 0;
    private int favoritosCantidad = 0;

    private Label carritoLabel;
    private Label favoritosLabel;

    private TilePane productos;
    

    @Override
    public void start(Stage stage) {

        // ===== ROOT =====
        BorderPane root = new BorderPane();

        root.setStyle("-fx-background-color:#f5f5f5;");

        // ===== LOGO =====
        Label logo = new Label("🏬CoreStore");

        logo.setFont(Font.font("Arial", FontWeight.BOLD, 28));

        // ===== BOTONES MENU =====
        Button inicio = crearBotonMenu("Inicio");

        Button catalogo = crearBotonMenu("Catálogo");

        Button ofertas = crearBotonMenu("Ofertas");

        Button soporte = crearBotonMenu("Soporte");

        // ===== ABRIR VENTANA OFERTAS =====
ofertas.setOnAction(e ->
        VentanaOfertas.mostrar(this)
);

        // ===== MENU =====
        HBox menu = new HBox(
                20,
                inicio,
                catalogo,
                ofertas,
                soporte
        );

        menu.setAlignment(Pos.CENTER_LEFT);

        // ===== BUSCADOR =====
        TextField buscador = new TextField();

        buscador.setPromptText("Buscar productos...");

        buscador.setPrefSize(420, 42);

        buscador.setStyle(
                "-fx-background-color:#f0f0f0;" +
                "-fx-background-radius:18;" +
                "-fx-padding:0 15 0 15;"
        );

        // ===== BOTON BUSCAR =====
        Button buscar = new Button("Buscar");

        buscar.setStyle(
                "-fx-background-color:black;" +
                "-fx-text-fill:white;" +
                "-fx-background-radius:12;"
        );

        // ===== ICONOS =====
        favoritosLabel = new Label("❤ 0");

        favoritosLabel.setStyle(
                "-fx-font-size:15px;" +
                "-fx-font-weight:bold;"
        );

        carritoLabel = new Label("🛒 0");

        carritoLabel.setStyle(
                "-fx-font-size:15px;" +
                "-fx-font-weight:bold;"
        );

        HBox iconos = new HBox(
                20,
                favoritosLabel,
                carritoLabel
        );

        // ===== NAVBAR =====
        BorderPane navbar = new BorderPane();

        navbar.setLeft(logo);

        navbar.setCenter(menu);

        HBox derecha = new HBox(
        15,
        buscador,
        buscar,
        iconos
        );

        derecha.setAlignment(Pos.CENTER_LEFT);

       // MOVER HACIA LA IZQUIERDA
       derecha.setTranslateX(-590);

       navbar.setRight(derecha);

        navbar.setPadding(new Insets(15));

        navbar.setStyle(
                "-fx-background-color:white;" +
                "-fx-border-color:#dddddd;"
        );

        // ===== SIDEBAR =====
        VBox sidebar = new VBox(18);

        sidebar.setPadding(new Insets(20));

        sidebar.setPrefWidth(240);

        sidebar.setStyle(
                "-fx-background-color:white;" +
                "-fx-background-radius:15;"
        );

        // ===== CATEGORIAS =====
        CheckBox iphone = new CheckBox("iPhone");

        CheckBox macbook = new CheckBox("MacBook");

        CheckBox ipad = new CheckBox("iPad");

        CheckBox accesorios = new CheckBox("Accesorios");

        // ===== CONDICIONES =====
        RadioButton nuevo = new RadioButton("Nuevo");

        RadioButton usado = new RadioButton("Usado");

        RadioButton reacondicionado =
                new RadioButton("Reacondicionado");

        ToggleGroup condiciones = new ToggleGroup();

        nuevo.setToggleGroup(condiciones);

        usado.setToggleGroup(condiciones);

        reacondicionado.setToggleGroup(condiciones);

        // ===== SLIDER PRECIO =====
        Slider slider = new Slider(0, 2000, 2000);

        slider.setShowTickLabels(true);

        slider.setShowTickMarks(true);

        slider.setMajorTickUnit(500);

        Label precio = new Label("Máximo: €2000");

        slider.valueProperty().addListener((a, b, c) ->

                precio.setText("Máximo: €" + c.intValue())
        );

        // ===== BOTONES FILTRO =====
        Button aplicar = new Button("Aplicar");

        aplicar.setStyle(
                "-fx-background-color:black;" +
                "-fx-text-fill:white;"
        );

        Button limpiar = new Button("Limpiar");

        // ===== SIDEBAR CONTENIDO =====
        sidebar.getChildren().addAll(

                new Label("Filtros"),

                new Label("Categorías"),

                iphone,
                macbook,
                ipad,
                accesorios,

                new Separator(),

                new Label("Condición"),

                nuevo,
                usado,
                reacondicionado,

                new Separator(),

                new Label("Precio"),

                precio,

                slider,

                new HBox(10, aplicar, limpiar)
        );

        // ===== TITULO =====
        Label titulo = new Label("Catálogo");

        titulo.setFont(
                Font.font("Arial", FontWeight.BOLD, 34)
        );

        Label subtitulo = new Label("12 productos disponibles");

        subtitulo.setTextFill(Color.GRAY);

        VBox header = new VBox(
                5,
                titulo,
                subtitulo
        );

        // ===== PANEL PRODUCTOS =====
        productos = new TilePane();
        productos.setPrefColumns(3);
        productos.setPrefTileWidth(360);
        productos.setPrefTileHeight(450);

        productos.setPadding(new Insets(20));
        productos.setHgap(25);
        productos.setVgap(25);
        
        productos.setPrefHeight(Region.USE_COMPUTED_SIZE);


        // ===== PRODUCTOS =====
        productos.getChildren().addAll(

                crearProducto(
    "/com/corestore/imag/01_iphone14.png",
    "iPhone 14 Pro Max 256GB",
    "€1399",
    "⭐ 4.8",
    "Nuevo",
    true
),

                crearProducto(
                        "/com/corestore/imag/02_macbook.png",
                        "MacBook Pro M2 512GB",
                        "€2199",
                        "⭐ 4.9",
                        "Nuevo",
                        false
                ),

                crearProducto(
                        "/com/corestore/imag/03_ipad.png",
                        "iPad Pro 11",
                        "€899",
                        "⭐ 4.7",
                        "Usado",
                        false
                ),

                crearProducto(
                        "/com/corestore/imag/04_airpods.png",
                        "AirPods Pro 2",
                        "€249",
                        "⭐ 4.6",
                        "Nuevo",
                        true
                ),

                crearProducto(
                        "/com/corestore/imag/05_magsafe.png",
                        "Cargador MagSafe",
                        "€45",
                        "⭐ 4.5",
                        "Reacondicionado",
                        false
                ),

                crearProducto(
                        "/com/corestore/imag/06_iphone13.png",
                        "iPhone 13 Mini",
                        "€769",
                        "⭐ 4.4",
                        "Usado",
                        false
                ),

                crearProducto(
                        "/com/corestore/imag/07_keyboard.png",
                        "Smart Keyboard",
                        "€199",
                        "⭐ 4.3",
                        "Reacondicionado",
                        false
                ),

                crearProducto(
                        "/com/corestore/imag/08_battery.png",
                        "MagSafe Battery",
                        "€129",
                        "⭐ 4.2",
                        "Usado",
                        false
                ),

                crearProducto(
                        "/com/corestore/imag/09_watch.png",
                        "Apple Watch Series 8",
                        "€499",
                        "⭐ 4.7",
                        "Nuevo",
                        true
                ),

                crearProducto(
                        "/com/corestore/imag/10_quantum.png",
                        "Auriculares Quantum",
                        "€19",
                        "⭐ 4.5",
                        "Nuevo",
                        false
                ),

                crearProducto(
                        "/com/corestore/imag/11_funda.png",
                        "Funda iPhone",
                        "€79",
                        "⭐ 4.3",
                        "Reacondicionado",
                        false
                ),

                crearProducto(
                        "/com/corestore/imag/12_display.png",
                        "Studio Display 27",
                        "€1799",
                        "⭐ 4.9",
                        "Nuevo",
                        true
                )
        );

        // ===== BUSCADOR =====
        Runnable buscarProductos = () -> {

            String texto =
                    buscador.getText().toLowerCase();

            for (Node nodo : productos.getChildren()) {

                VBox card = (VBox) nodo;

                Label nombre =
                        (Label) card.getChildren().get(2);

                boolean mostrar =
                        nombre.getText()
                                .toLowerCase()
                                .contains(texto);

                card.setVisible(mostrar || texto.isEmpty());

                card.setManaged(mostrar || texto.isEmpty());
            }
        };

        buscar.setOnAction(e -> buscarProductos.run());

        buscador.setOnAction(e -> buscarProductos.run());

        // ===== FILTROS =====
        aplicar.setOnAction(e -> {

            for (Node nodo : productos.getChildren()) {

                VBox card = (VBox) nodo;

                Label nombre =
                        (Label) card.getChildren().get(2);

                Label precioLabel =
                        (Label) card.getChildren().get(4);

                Label condicionLabel =
                        (Label) card.getChildren().get(6);

                String texto =
                        nombre.getText().toLowerCase();

                String condicion =
                        condicionLabel.getText().toLowerCase();

                double valor =
                        Double.parseDouble(
                                precioLabel.getText()
                                        .replace("€", "")
                        );

                boolean mostrar = true;

                // ===== CATEGORIAS =====
                if (iphone.isSelected()
                        && !texto.contains("iphone"))
                    mostrar = false;

                if (macbook.isSelected()
                        && !texto.contains("macbook"))
                    mostrar = false;

                if (ipad.isSelected()
                        && !texto.contains("ipad"))
                    mostrar = false;

                // ===== PRECIO =====
                if (valor > slider.getValue())
                    mostrar = false;

                // ===== CONDICION =====
                if (nuevo.isSelected()
                        && !condicion.contains("nuevo"))
                    mostrar = false;

                if (usado.isSelected()
                        && !condicion.contains("usado"))
                    mostrar = false;

                if (reacondicionado.isSelected()
                        && !condicion.contains("reacondicionado"))
                    mostrar = false;

                card.setVisible(mostrar);

                card.setManaged(mostrar);
            }
        });

        // ===== LIMPIAR =====
        limpiar.setOnAction(e -> {

            iphone.setSelected(false);

            macbook.setSelected(false);

            ipad.setSelected(false);

            accesorios.setSelected(false);

            condiciones.selectToggle(null);

            slider.setValue(2000);

            buscador.clear();

            for (Node nodo : productos.getChildren()) {

                nodo.setVisible(true);

                nodo.setManaged(true);
            }
        });

        // ===== SCROLL =====
        ScrollPane scroll = new ScrollPane(productos);
        scroll.setFitToWidth(true);
        scroll.setPannable(true);
        scroll.setMinHeight(0);
        
        VBox.setVgrow(scroll, Priority.ALWAYS);
        VBox contenido = new VBox(25, header, scroll);
        
        VBox.setVgrow(scroll, Priority.ALWAYS);
        VBox.setVgrow(contenido, Priority.ALWAYS);
        scroll.setFitToWidth(true);
         

        contenido.setPadding(new Insets(20));

        // ===== CENTRO =====
        HBox centro = new HBox(30, sidebar, contenido);
        HBox.setHgrow(contenido, Priority.ALWAYS);
        centro.setFillHeight(true);
        centro.setAlignment(Pos.TOP_LEFT);

        HBox.setHgrow(contenido, Priority.ALWAYS);
        centro.setPadding(new Insets(20));

        // ===== ROOT =====
        root.setTop(navbar);

        root.setCenter(centro);

        // ===== ESCENA =====
        Scene scene = new Scene(root, 1920, 1080);

        stage.setTitle("CoreStore");

        stage.setMaximized(true);

        stage.setScene(scene);

        stage.show();
    }

    // ===== CREAR PRODUCTO =====
    public VBox crearProducto(
            String ruta,
            String nombre,
            String precio,
            String rating,
            String condicion,
            boolean oferta
    ) {

        // ===== IMAGEN =====
        System.out.println(ruta);

URL url = getClass().getResource(ruta);

if (url == null) {
    System.out.println("ERROR: No se encontró la imagen -> " + ruta);
    return new VBox();

}

ImageView imagen = new ImageView(
        new Image(url.toExternalForm())
);

        imagen.setFitWidth(145);

        imagen.setFitHeight(145);

        imagen.setPreserveRatio(true);

        // ===== OFERTA =====
        Label ofertaLabel = new Label(
                oferta ? "🔥 EN OFERTA" : ""
        );

        // SOLO MOSTRAR SI ESTA EN OFERTA
        if (oferta) {

            ofertaLabel.setStyle(
                    "-fx-background-color:#ff4d4d;" +
                    "-fx-text-fill:white;" +
                    "-fx-padding:5 10 5 10;" +
                    "-fx-background-radius:10;" +
                    "-fx-font-weight:bold;"
            );

        } else {

            // OCULTAR COMPLETAMENTE LOS QUE NO ESTAN EN OFERTA
            ofertaLabel.setManaged(false);

            ofertaLabel.setVisible(false);
        }

        // ===== TITULO =====
        Label titulo = new Label(nombre);

        titulo.setWrapText(true);

        titulo.setMaxWidth(240);

        titulo.setFont(
                Font.font("Arial", FontWeight.BOLD, 14)
        );

        // ===== DESCRIPCION =====
        Label descripcion = new Label(
                "Producto original Apple con garantía incluida"
        );

        descripcion.setWrapText(true);

        descripcion.setMaxWidth(240);

        descripcion.setTextFill(Color.GRAY);

        // ===== PRECIO =====
        Label valor = new Label(precio);

        valor.setFont(
                Font.font("Arial", FontWeight.BOLD, 18)
        );

        // ===== RATING =====
        Label estrellas = new Label(rating);

        estrellas.setTextFill(Color.GRAY);

        // ===== CONDICION =====
        Label condicionLabel = new Label(condicion);

        condicionLabel.setTextFill(Color.DARKGRAY);

        // ===== BOTON VER =====
        Button ver = new Button("Ver");

        // ===== FAVORITO =====
        Button favorito = new Button("❤");

        favorito.setUserData(false);

        favorito.setOnAction(e -> {

            boolean activo =
                    (boolean) favorito.getUserData();

            favoritosCantidad += activo ? -1 : 1;

            favorito.setStyle(
                    activo
                            ? "-fx-background-color:#eeeeee;"
                            : "-fx-background-color:#ff4d6d;-fx-text-fill:white;"
            );

            favorito.setUserData(!activo);

            favoritosLabel.setText(
                    "❤ " + favoritosCantidad
            );

            FavoritoAnimacion.animarFavorito(favorito);
        });

        // ===== CARRITO =====
        Button carrito = new Button("Añadir");

        carrito.setUserData(false);

        carrito.setStyle(
                "-fx-background-color:black;" +
                "-fx-text-fill:white;"
        );

        carrito.setOnAction(e -> {

            boolean activo =
                    (boolean) carrito.getUserData();

            carritoCantidad += activo ? -1 : 1;

            carrito.setText(
                    activo ? "Añadir" : "Quitar"
            );

            carrito.setStyle(
                    activo
                            ? "-fx-background-color:black;-fx-text-fill:white;"
                            : "-fx-background-color:gray;-fx-text-fill:white;"
            );

            carrito.setUserData(!activo);

            carritoLabel.setText(
                    "🛒 " + carritoCantidad
            );

            CarritoAnimacion.animarBoton(carrito);

            CarritoAnimacion.animarCarrito(carritoLabel);
        });

        // ===== BOTONES =====
        HBox botones = new HBox(
                10,
                ver,
                favorito,
                carrito
        );

        botones.setAlignment(Pos.CENTER);

        // ===== CARD =====
        VBox card = new VBox(
                10,
                imagen,
                ofertaLabel,
                titulo,
                descripcion,
                valor,
                estrellas,
                condicionLabel,
                botones
        );

        card.setAlignment(Pos.TOP_CENTER);

        card.setPadding(new Insets(14));

        card.setPrefWidth(340);

        card.setMinHeight(470);

        card.setStyle(
                "-fx-background-color:white;" +
                "-fx-background-radius:15;" +
                "-fx-border-radius:15;" +
                "-fx-border-color:#dddddd;"
        );

        return card;
    }

    // ===== BOTONES MENU =====
    private Button crearBotonMenu(String texto) {

        Button boton = new Button(texto);

        boton.setStyle(
                "-fx-background-color:transparent;"
        );

        return boton;
    }

    // ===== MAIN =====
    public static void main(String[] args) {

        launch(args);
    }
}